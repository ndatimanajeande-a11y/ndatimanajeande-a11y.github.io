# Ndatimana — personal website

This repository is designed for GitHub Pages.

## Publish
1. Create a **public** repository named exactly `ndatimanajeande-a11y.github.io`.
2. Upload every file in this folder to the repository root (not inside another folder).
3. Open Settings → Pages.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then Save.
6. Wait for the deployment and visit https://ndatimanajeande-a11y.github.io

## Website files
- `index.html` — homepage
- `blog.html` — articles
- `profile-photo.jpg` — profile image
- `favicon.svg` — browser icon
- `sitemap.xml` and `robots.txt` — search engine discovery
- `_headers` — optional static host configuration; GitHub Pages does not apply Cloudflare-style headers.

## Important
Review all personal claims and links before publishing. The articles are editable draft content. GitHub Pages serves public repository content publicly.
